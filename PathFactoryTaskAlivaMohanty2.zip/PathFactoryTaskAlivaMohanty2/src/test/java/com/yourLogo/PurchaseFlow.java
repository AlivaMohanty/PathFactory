package com.yourLogo;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PurchaseFlow {

	WebDriver driver = null;
	int pageLoadTimeout = 40;
	int implicitWait = 30;
	
	
	@BeforeClass(description = "Run before the test")
	
	public void beforeClass() throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("http://automationpractice.com/index.php");		  
		driver.manage().timeouts().pageLoadTimeout(pageLoadTimeout, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(implicitWait, TimeUnit.SECONDS);		
	}
	
	/**
	 * This test case will verify: -
	 * 1. User is able to navigate to the Landing page providing the URL
	 * 2. User is able to select Sign-in button to move to Login Page
	 */
	
	@Test(priority=1, description="Successfully login to application")
	public void testLandingPage() {
		
		WebDriverWait wait = new WebDriverWait(driver,pageLoadTimeout);
		WebElement signInButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@class,'login')]")));
		
		Assert.assertEquals("My Store", driver.getTitle());
		signInButton.click();
				
	}
	
	/**
	 * The DataProvider provides email address and password to login to application
	 * @return
	 */
	
	@DataProvider(name ="LoginCredentialProvider")
	public Object[][] getLoginData(){
		return new Object[][] {{"a.mohanty@gmx.com","Ahaya"}};
	}
	
	/**
	 * This method verifies: -
	 * 1. User is successfully able to enter valid email address and password in to application
	 * 2. User is successfully able to login in to application and my account page should display
	 * Pre-Condition: - User should already create the account and have valid email address and password
	 * @param email
	 * @param password
	 * @throws InterruptedException
	 */
	
	@Test(priority=2, dataProvider="LoginCredentialProvider", description="Successfully login to application")
	public void testLoginPage(String email, String password) throws InterruptedException {
		
		WebDriverWait wait = new WebDriverWait(driver,pageLoadTimeout);
		WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='SubmitLogin']")));

		//Enter email address	
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys(email);
		
		//Wait for 1 sec before moving to Password field
		Thread.sleep(1000);
		
		//Enter password	
		driver.findElement(By.xpath("//input[@id='passwd']")).sendKeys(password);

		//Click on the Sing in button
		loginButton.click();
		
		//Verify that My account page will come after successful login
		Assert.assertEquals("My account - My Store", driver.getTitle());
		
	}
	
	/**
	 * This data provider provides the data for the order confirmation
	 * @return
	 */
	
	@DataProvider(name ="OrderItemsProvider")
	public Object[][] getOrderItems(){
		return new Object[][] {{"Women", "Tops", "T-Shirts"}};
	}
	
	/**
	 * This method verifies: -
	 * 1. User is able to select the "Women" tab
	 * 2. User is able to select the "Tops" from the subcategories
	 * 3. User is able to select one items as "T-Shirts" from Tops subcategories
	 * @param womenItem
	 * @param category
	 * @param item
	 * @throws InterruptedException 
	 */
	
	@Test(priority=3, dataProvider="OrderItemsProvider", description="Test the Order Confirmation")
	public void testOrderConfirmation(String womenItem, String category, String item) throws InterruptedException {
		
		//Fetch the menu items 		
		WebElement topMenu = driver.findElement(By.tagName("ul"));		
		WebElement getMenuItem = topMenu.findElement(By.tagName("li"));
		
		//Click the Women Tab
		if(womenItem.equalsIgnoreCase(getMenuItem.getText())) {
			
				getMenuItem.click();
		}
		
		Thread.sleep(1000);
		
		//Select one item as Tops from the SubCategories
		WebElement subCategoriesList = driver.findElement(By.xpath("//*[@id='categories_block_left']//ul"));
		List<WebElement> getSubCategories = subCategoriesList.findElements(By.xpath(".//li"));
				
		for(WebElement dressesButton : getSubCategories) {

		WebElement dressToggleButton = dressesButton.findElement(By.xpath("//*[@id='categories_block_left']//span"));
		WebElement selectTops = dressesButton.findElement(By.xpath(".//a"));
		String selectTopsValue = selectTops.getText();
		System.out.println(selectTopsValue);
					
		if(selectTopsValue != null && selectTopsValue.contains(category)) {
			
				//Click on the Tops toggle button
				dressToggleButton.click();
				break;
						
		   }
		}
		Thread.sleep(2000);
		
		//Select One item as T-Shirt from Tops Sub categories
		WebElement listOfItems = driver.findElement(By.xpath("//*[@id='categories_block_left']//li[1]/ul"));
		WebElement itemValue = listOfItems.findElement(By.xpath(".//li[1]/a"));

		if(item.equalsIgnoreCase(itemValue.getText())) {
			
			Thread.sleep(2000);
			
			//Select the T-Shirts button
			itemValue.click();
			
		 }
		}
	
	/**
	 * This method will verify:-
	 * 1. User is able to navigate to the 1st product and add one item to the card  
	 * @param addToCart
	 * @throws InterruptedException
	 */
		
	@Test(priority = 4, description = "Add to cart")
	public void testAddToCart() throws InterruptedException {

		Thread.sleep(2000);

		// Fetch all products under T-Shists
		List<WebElement> liElements = driver.findElements(By.xpath("//ul[contains(@class,'product_list')]/li"));

		// select the 1st product
		WebElement getFirstProduct = liElements.get(0);

		WebElement firstProduct = getFirstProduct.findElement(By.xpath(".//img"));

		// Move the control to getFirstProduct element
		Actions actions = new Actions(driver);
		Thread.sleep(2000);
		actions.moveToElement(firstProduct);
		actions.click().build().perform();

		Thread.sleep(2000);

		WebElement buyForm = driver.findElement(By.xpath("//form[@id='buy_block']"));
		WebElement boxCart = buyForm.findElement(By.xpath(".//p[@id='add_to_cart']"));
		WebElement addToCartSubmit = driver.findElement(By.xpath(".//button[@type='submit']"));
		addToCartSubmit.click();
	}

	/**
	 * This data provider returns successful message and proceed to check-out of the selected items
	 * @return
	 */
	
	@DataProvider(name="ProceedToCheckoutProvider")
	public Object[][] getProceedToCheckOut(){
		return new Object[][] {{"Product successfully added to your shopping cart", "Proceed to checkout"}};
	}

	/**
	 * This method verifies whether User is successfully able to add the product to shopping cart and proceed checkout with the items in the Pop Up window
	 * @param message
	 * @param checkOut
	 * @throws InterruptedException 
	 */
	
	@Test(priority=5, dataProvider="ProceedToCheckoutProvider", description="Proceeding to checkout")
	public void testProceedToCheckout(String message, String checkOut) throws InterruptedException {

		Thread.sleep(4000);
		//Fetch all messages
		WebElement successMessage = driver.findElement(By.xpath("//div[contains(@class,'layer_cart_product')]"));
		
		//Fetch the text of messages
		String successMessageValue = successMessage.getText();
		
		//Verify whether User is successfully able to add the product
		Assert.assertTrue(successMessageValue.contains(message));
		
		//Select the Proceed to checkout in Pop up windows
		WebElement buttonContainer = driver.findElement(By.xpath("//div[contains(@class,'button-container')]"));
		Assert.assertNotNull(buttonContainer);

		WebElement proceedCheckout = buttonContainer.findElement(By.xpath(".//a[contains(@title,'Proceed to checkout')]"));
		Assert.assertNotNull(proceedCheckout);

		Thread.sleep(2000);

		proceedCheckout.click();
	}
	

	/**
	 * This method verifies: -
	 * 1. User is able to navigate to Shopping Cart Summary page, is able to see the number of product selected and the total price
	 * 2. User is able to see the delivery address and billing address
	 * 3. User is able to select the terms of service
	 * 4. User is able to pay be bank wire
	 * 5. User is able to see the bank wie summary and confirm the order
	 * 6. The order is confirmed and user is able to see the Order confirmation page 
	 * @param inStock
	 * @throws InterruptedException
	 */
	
	@Test(priority =6, description ="Verify the Summary page")
	public void testSummaryPage() throws InterruptedException {
		
		//Verify User is in Summary page and see the number of products in cart
		WebElement cartSummaryTitle = driver.findElement(By.xpath("//h1[@id='cart_title']"));
		
		System.out.println("Shopping cart name and number of product is  " +cartSummaryTitle.getText());
		
		Assert.assertNotNull(cartSummaryTitle.getText());
				
		//Print the total price
		WebElement totalPrice = driver.findElement(By.xpath("//span[@id='total_price']"));
		System.out.println("The total price is = " +totalPrice.getText());
		
		//Click on the Proceed to Checkout
		WebElement proceedToCheckout = driver.findElement(By.xpath("//span[text()='Proceed to checkout']"));
		Assert.assertNotNull(proceedToCheckout);

		Thread.sleep(2000);

		//Click the proceed to checkout button in summary page
		proceedToCheckout.click();
		
		Thread.sleep(2000);
		
		//Print the delivery address		
		WebElement deliveryAddress = driver.findElement(By.xpath("//ul[@id='address_delivery']"));
		System.out.println("The delivery Address is: -" +deliveryAddress.getText());
		
		Thread.sleep(2000);
		
		//Print the billing or invoice address
		WebElement billingAddress = driver.findElement(By.xpath("//ul[@id='address_invoice']"));	
		System.out.println("The billing Address is: -" +billingAddress.getText());
	
		//Click the proceed to checkout button in address page
		proceedToCheckout.click();
		
		//Click on the Terms of service checkbox in shipping page
		WebElement termsOfService = driver.findElement(By.xpath("//input[@type='checkbox']"));
		termsOfService.click();
		
		Thread.sleep(2000);
		
		//Click the proceed to checkout button in shipping page
		proceedToCheckout.click();
		
		//Select the payment mode as Bank Wire
		WebElement paymentMode = driver.findElement(By.xpath("//a[@class='bankwire']"));
		paymentMode.click();
		
		//Click on the order confirmation button
		
		WebElement orderConfirmation = driver.findElement(By.xpath("//button[@type='submit']/span[text()='I confirm my order']"));
		orderConfirmation.click();
		
		//Verify that My account page will come after successful login
		Assert.assertEquals("Order Confirmation - My Store", driver.getTitle());
	}
	

	

	@AfterClass(description ="Run after our test")
	 public void tearDown() throws InterruptedException {
		  Thread.sleep(1000);
		  
		  //Logout from the application
		  driver.findElement(By.xpath("//a[contains(@class,'logout')]"));
		  
		  System.out.println("User is logged out from the Your Logo application");
		  //Close the browser
		  driver.quit();
		  
		  this.driver = null;
	  }	
}
